EASY = 'easy'
FLAT = 'flat'
HARD = 'hard'
TEST = 'test'

EASY_SIZE = (3, 3)
FLAT_SIZE = (1, 12)
HARD_SIZE = (5, 6)
TEST_SIZE = (1, 8)

TOURNAMENT = 'tournament'
ROULETTE = 'roulette'


